const cipheredTestData = {
    'content-article-img': 'LmNvbnRlbnRfYXJ0aWNsZSBpbWc=', 
    'content-article-img-first': 'LmNvbnRlbnRfYXJ0aWNsZSAuc2VjdGlvbl9jb250ZW50Om50aC1jaGlsZCgyKSBpbWcuZGVza19pbWFnZQ==',
    'content-article-img-second': 'LmNvbnRlbnRfYXJ0aWNsZSAuc2VjdGlvbl9jb250ZW50Om50aC1jaGlsZCgzKSBpbWcucGhvbmVfaW1hZ2U=',
    'content-article-img-third': 'LmNvbnRlbnRfYXJ0aWNsZSAuc2VjdGlvbl9jb250ZW50Om50aC1jaGlsZCg0KSBpbWcuZGVza19pbWFnZQ==',
    'content-article-img-fourth': 'LmNvbnRlbnRfYXJ0aWNsZSAuc2VjdGlvbl9jb250ZW50Om50aC1jaGlsZCg1KSBpbWcucGhvbmVfaW1hZ2U='  
};

module.exports = { cipheredTestData };
